//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// inference_routine_initialize.h
//
// Code generation for function 'inference_routine_initialize'
//

#ifndef INFERENCE_ROUTINE_INITIALIZE_H
#define INFERENCE_ROUTINE_INITIALIZE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void inference_routine_initialize();

#endif
// End of code generation (inference_routine_initialize.h)
