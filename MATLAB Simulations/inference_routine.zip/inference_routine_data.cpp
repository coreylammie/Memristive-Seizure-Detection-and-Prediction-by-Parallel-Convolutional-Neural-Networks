//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// inference_routine_data.cpp
//
// Code generation for function 'inference_routine_data'
//

// Include files
#include "inference_routine_data.h"

// Variable Definitions
unsigned int state[625];

boolean_T isInitialized_inference_routine{false};

// End of code generation (inference_routine_data.cpp)
