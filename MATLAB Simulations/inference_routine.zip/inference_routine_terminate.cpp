//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// inference_routine_terminate.cpp
//
// Code generation for function 'inference_routine_terminate'
//

// Include files
#include "inference_routine_terminate.h"
#include "inference_routine_data.h"

// Function Definitions
void inference_routine_terminate()
{
  // (no terminate code required)
  isInitialized_inference_routine = false;
}

// End of code generation (inference_routine_terminate.cpp)
